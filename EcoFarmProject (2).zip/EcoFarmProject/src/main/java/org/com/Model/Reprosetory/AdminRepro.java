package org.com.Model.Reprosetory;

import org.com.Model.Entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRepro extends JpaRepository <Admin,String>
{
	
	
}
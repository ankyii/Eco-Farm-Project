package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Cart;
import org.com.Model.Entity.Product;
import org.com.Model.Reprosetory.CartRepro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartServices {
	
	@Autowired
	CartRepro cr;

	public void addCart(Cart a) 
	{
		cr.save(a); 		
	}
	public void deleteproduct(int id) 
	{
		cr.deleteById(id);			
	}


	public void updateproduct(Cart p) 
	{		
		cr.save(p); 
	}

	public Cart findbyid(int d) 
	{
		Cart PD = (Cart)cr.findById(d).get();
		return PD;
	}
	
}

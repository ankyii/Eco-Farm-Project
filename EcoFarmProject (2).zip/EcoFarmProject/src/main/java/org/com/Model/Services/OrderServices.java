package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Order;
import org.com.Model.Entity.Product;
import org.com.Model.Reprosetory.OrderRepro;
import org.com.Model.Reprosetory.ProductRepro;
import org.springframework.beans.factory.annotation.Autowired;

public class OrderServices {
	@Autowired
	OrderRepro pr;

	public ArrayList<Order> getAllProduct() {
		ArrayList<Order> p = new ArrayList<Order>();
		Iterator I = pr.findAll().iterator();

		while (I.hasNext()) {
			Order pro = (Order) I.next();
			p.add(pro);
		}
		System.out.println(p);
		return p;
	}
	
	public void addOrder(Order a) 
	{
		pr.save(a); 
				
	}
	public void deleteOrder(int id) 
	{
		pr.deleteById(id);			
	}


	public void updateOrder(Order p) 
	{		
		pr.save(p); 
	}

	public Order findbyid(int d) 
	{
		Order PD = (Order)pr.findById(d).get();
		return PD;
	}
	

}

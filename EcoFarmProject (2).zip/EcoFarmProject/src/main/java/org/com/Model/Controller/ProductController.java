package org.com.Model.Controller;

import java.util.List;

import org.com.Model.Entity.Admin;
import org.com.Model.Entity.Product;
import org.com.Model.Services.AdminServices;
import org.com.Model.Services.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class ProductController {

	@Autowired
	ProductServices Ab;
	
	@GetMapping(path="/products")
	public List<Product> getAllProduct()
	{
		return Ab.getAllProduct();
	}
	
	@GetMapping("/product/{pid}")
	public Product getProductID(@PathVariable("pid") int d)
	{
		return Ab.findbyid(d);
	}
	
	@PostMapping("/addproduct")
	public int saveProduct(@RequestBody Product pd)
	{
		Ab.addProduct(pd);
		return pd.getP_Code();
		
	}
	
	@PutMapping("/updateproduct")
	public int updateProduct(@RequestBody Product pd)
	{	   
		Ab.updateproduct(pd);
		return pd.getP_Code();
		
	}
	
	@DeleteMapping("/deleteproduct/{id}")
	public void deleteProduct(@PathVariable("pid") int d)
	{
		Ab.deleteproduct(d);		
	}
}

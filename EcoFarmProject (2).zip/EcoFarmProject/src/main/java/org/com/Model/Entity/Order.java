package org.com.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="order")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int O_Id;
	
	@Column(name =" O_Date")
	private String O_Date;
	
	@Column(name =" Cu_Id")
	private int Cu_Id;
	
	@Column(name =" P_Code")
	private int P_Code;
	
	@Column(name =" O_Qunatity")
	private int O_Qunatity;
	
	@Column(name =" O_Bill")
	private double O_Bill;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getO_Id() {
		return O_Id;
	}
	public void setO_Id(int o_Id) {
		O_Id = o_Id;
	}
	public String getO_Date() {
		return O_Date;
	}
	public void setO_Date(String o_Date) {
		O_Date = o_Date;
	}
	public int getCu_Id() {
		return Cu_Id;
	}
	public void setCu_Id(int cu_Id) {
		Cu_Id = cu_Id;
	}
	public int getP_Code() {
		return P_Code;
	}
	public void setP_Code(int p_Code) {
		P_Code = p_Code;
	}
	public int getO_Qunatity() {
		return O_Qunatity;
	}
	public void setO_Qunatity(int o_Qunatity) {
		O_Qunatity = o_Qunatity;
	}
	public double getO_Bill() {
		return O_Bill;
	}
	public void setO_Bill(double o_Bill) {
		O_Bill = o_Bill;
	}

}

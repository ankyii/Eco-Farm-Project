package org.com.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="company")
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int C_Id;
	
	@Column(name =" C_Name")
	private String C_Name;
	
	@Column(name =" C_Location")
	private String C_Location;
	
	@Column(name =" C_Mobile")
	private String C_Mobile;
	
	@Column(name =" C_Date")
	private String C_Date;
	
	@Column(name =" C_Email")
	private String C_Email;
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getC_Id() {
		return C_Id;
	}
	public void setC_Id(int c_Id) {
		C_Id = c_Id;
	}
	public String getC_Name() {
		return C_Name;
	}
	public void setC_Name(String c_Name) {
		C_Name = c_Name;
	}
	public String getC_Location() {
		return C_Location;
	}
	public void setC_Location(String c_Location) {
		C_Location = c_Location;
	}
	public String getC_Mobile() {
		return C_Mobile;
	}
	public void setC_Mobile(String c_Mobile) {
		C_Mobile = c_Mobile;
	}
	public String getC_Date() {
		return C_Date;
	}
	public void setC_Date(String c_Date) {
		C_Date = c_Date;
	}
	public String getC_Email() {
		return C_Email;
	}
	public void setC_Email(String c_Email) {
		C_Email = c_Email;
	}
	
	
	

}

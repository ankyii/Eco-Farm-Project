package org.com.Model.Reprosetory;

import org.com.Model.Entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepro extends JpaRepository <Cart,Integer>
{
	
	
}

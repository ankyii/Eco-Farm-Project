package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Company;
import org.com.Model.Entity.Product;
import org.com.Model.Reprosetory.CompanyRepro;
import org.com.Model.Reprosetory.ProductRepro;
import org.springframework.beans.factory.annotation.Autowired;

public class CompanyService {
	@Autowired
	CompanyRepro pr;

	public ArrayList<Company> getAllCompany() {
		ArrayList<Company> p = new ArrayList<Company>();
		Iterator I = pr.findAll().iterator();

		while (I.hasNext()) {
			Company pro = (Company) I.next();
			p.add(pro);
		}
		System.out.println(p);
		return p;
	}
	
	public void addCompany(Company a) 
	{
		pr.save(a); 
				
	}
	public void deleteCompany(int id) 
	{
		pr.deleteById(id);			
	}


	public void updateCompany(Company p) 
	{		
		pr.save(p); 
	}

	public Company findbyid(int d) 
	{
		Company PD = (Company)pr.findById(d).get();
		return PD;
	}
	


}

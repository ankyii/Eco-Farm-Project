package org.com.Model.Controller;

import java.util.ArrayList;
import java.util.List;

import org.com.Model.Entity.Admin;
import org.com.Model.Reprosetory.AdminRepro;
import org.com.Model.Services.AdminServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class AdminControll {
	
	@Autowired
	AdminServices Ab;
	
	@GetMapping(path="/a")
	public String home() {
		System.out.println("hiii");
		return "abc.jsp";
	}
	/*public List<Admin> getAllAdmin()
	{
		return Ab.getAllAdmin();
	}*/
	
	@PostMapping("/addpadmin")
	public String saveAdmin(@RequestBody Admin ad)
	{
		Ab.addadmin(ad);
		return ad.getA_Username();
	}
}

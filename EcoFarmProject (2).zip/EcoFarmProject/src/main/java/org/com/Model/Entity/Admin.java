package org.com.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	
	@Id
	@Column(name =" A_Username")
	private String A_Username;
	@Column(name =" A_Password")
	private String A_Password;
	public String getA_Username() {
		return A_Username;
	}
	public void setA_Username(String a_Username) {
		A_Username = a_Username;
	}
	public String getA_Password() {
		return A_Password;
	}
	public void setA_Password(String a_Password) {
		A_Password = a_Password;
	}
//	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

}

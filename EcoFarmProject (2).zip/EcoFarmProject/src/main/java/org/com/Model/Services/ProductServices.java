package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Admin;
import org.com.Model.Entity.Product;
import org.com.Model.Reprosetory.AdminRepro;
import org.com.Model.Reprosetory.ProductRepro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductServices {
	
	@Autowired
	ProductRepro pr;

	public ArrayList<Product> getAllProduct() {
		ArrayList<Product> p = new ArrayList<Product>();
		Iterator I = pr.findAll().iterator();

		while (I.hasNext()) {
			Product pro = (Product) I.next();
			p.add(pro);
		}
		System.out.println(p);
		return p;
	}
	
	public void addProduct(Product a) 
	{
		pr.save(a); 
				
	}
	public void deleteproduct(int id) 
	{
		pr.deleteById(id);			
	}


	public void updateproduct(Product p) 
	{		
		pr.save(p); 
	}

	public Product findbyid(int d) 
	{
		Product PD = (Product)pr.findById(d).get();
		return PD;
	}
	

}

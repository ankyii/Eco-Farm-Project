package org.com.Model.Controller;

import java.util.List;

import org.com.Model.Entity.Customer;
import org.com.Model.Entity.Product;
import org.com.Model.Services.CustomerService;
import org.com.Model.Services.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class CustomerController {
	
	@Autowired
	CustomerService Ab;
	
	@GetMapping(path="/customers")
	public List<Customer> getAllProduct()
	{
		return Ab.getAllCustomer();
	}
	
	@GetMapping("/customer/{cid}")
	public Customer getProductID(@PathVariable("cid") int d)
	{
		return Ab.findbyid(d);
	}
	
	@PostMapping("/addcustomer")
	public int saveCustomer(@RequestBody Customer pd)
	{
		Ab.addCustomer(pd);
		return pd.getCu_Id();
		
	}
	
	@PutMapping("/updatecustomer")
	public int updateCustomer(@RequestBody Customer pd)
	{	   
		Ab.updateCustomer(pd);
		return pd.getCu_Id();
		
	}
	
	@DeleteMapping("/deletecustomer/{id}")
	public void deleteCustomer(@PathVariable("cid") int d)
	{
		Ab.deleteCustomer(d);		
	}

}

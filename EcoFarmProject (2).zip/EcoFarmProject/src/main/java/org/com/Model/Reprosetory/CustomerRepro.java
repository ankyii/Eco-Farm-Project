package org.com.Model.Reprosetory;

import org.com.Model.Entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CustomerRepro extends JpaRepository <Customer,Integer>
{
	
	
}
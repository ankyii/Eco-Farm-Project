package org.com.Model.Entity;

import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cart")
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Ca_Id;
	
	@Column(name =" P_Code")
	private int P_Code;
	
	@Column(name =" O_Date")
	private int O_Date;
	
	@Column(name =" Qty")
	private int Qty;
	
	@Column(name =" Cu_Id")
	private int Cu_Id;
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCa_Id() {
		return Ca_Id;
	}
	public void setCa_Id(int ca_Id) {
		Ca_Id = ca_Id;
	}
	public int getP_Code() {
		return P_Code;
	}
	public void setP_Code(int p_Code) {
		P_Code = p_Code;
	}
	public int getO_Date() {
		return O_Date;
	}
	public void setO_Date(int o_Date) {
		O_Date = o_Date;
	}
	public int getQty() {
		return Qty;
	}
	public void setQty(int qty) {
		Qty = qty;
	}
	public int getCu_Id() {
		return Cu_Id;
	}
	public void setCu_Id(int cu_Id) {
		Cu_Id = cu_Id;
	}

	
	

}

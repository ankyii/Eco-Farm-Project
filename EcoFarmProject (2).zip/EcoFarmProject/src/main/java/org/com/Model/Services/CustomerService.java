package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Customer;
import org.com.Model.Entity.Product;
import org.com.Model.Reprosetory.CustomerRepro;
import org.com.Model.Reprosetory.ProductRepro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

	@Autowired
	CustomerRepro pr;

	public ArrayList<Customer> getAllCustomer() {
		ArrayList<Customer> p = new ArrayList<Customer>();
		Iterator I = pr.findAll().iterator();

		while (I.hasNext()) {
			Customer pro = (Customer) I.next();
			p.add(pro);
		}
		System.out.println(p);
		return p;
	}
	
	public void addCustomer(Customer a) 
	{
		pr.save(a); 
				
	}
	public void deleteCustomer(int id) 
	{
		pr.deleteById(id);			
	}


	public void updateCustomer(Customer p) 
	{		
		pr.save(p); 
	}

	public Customer findbyid(int d) 
	{
		Customer PD = (Customer)pr.findById(d).get();
		return PD;
	}
	

}

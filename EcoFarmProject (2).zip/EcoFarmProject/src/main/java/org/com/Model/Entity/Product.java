package org.com.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int P_Code;
	
	@Column(name =" P_Category")
	private String P_Category;
	
	@Column(name =" P_Name")
	private String P_Name;
	
	@Column(name =" P_Price")
	private Double P_Price;
	
	@Column(name =" P_Stock")
	private int P_Stock;
	
	@Column(name =" P_Description")
	private String P_Description;
	
	@Column(name =" P_Image")
	private String P_Image;
	public int getP_Code() {
		return P_Code;
	}
	public void setP_Code(int p_Code) {
		P_Code = p_Code;
	}
	public String getP_Category() {
		return P_Category;
	}
	public void setP_Category(String p_Category) {
		P_Category = p_Category;
	}
	public String getP_Name() {
		return P_Name;
	}
	public void setP_Name(String p_Name) {
		P_Name = p_Name;
	}
	public Double getP_Price() {
		return P_Price;
	}
	public void setP_Price(Double p_Price) {
		P_Price = p_Price;
	}
	public int getP_Stock() {
		return P_Stock;
	}
	public void setP_Stock(int p_Stock) {
		P_Stock = p_Stock;
	}
	public String getP_Description() {
		return P_Description;
	}
	public void setP_Description(String p_Description) {
		P_Description = p_Description;
	}
	public String getP_Image() {
		return P_Image;
	}
	public void setP_Image(String p_Image) {
		P_Image = p_Image;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}

package org.com.Model.Controller;

import java.util.List;

import org.com.Model.Entity.Order;
import org.com.Model.Entity.Product;
import org.com.Model.Services.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class OderController {
	@Autowired
	OderController Ab;
	
	@GetMapping(path="/orders")
	public List<Order> getAllProduct()
	{
		return Ab.getAllProduct();
	}
	
	@GetMapping("/order/{pid}")
	public Order getOrderID(@PathVariable("pid") int d)
	{
		return Ab.getOrderID(d);
	}
	
	@PostMapping("/addorder")
	public int saveOrder(@RequestBody Order pd)
	{
		Ab.saveOrder(pd);
		return pd.getP_Code();
		
	}
	
	@PutMapping("/updateorder")
	public int updateOrder(@RequestBody Order pd)
	{	   
		Ab.updateOrder(pd);
		return pd.getP_Code();
		
	}
	
	@DeleteMapping("/deleteorder/{id}")
	public void deleteOrder(@PathVariable("pid") int d)
	{
		Ab.deleteOrder(d);	
}
}

package org.com.Model.Services;

import java.util.ArrayList;
import java.util.Iterator;

import org.com.Model.Entity.Admin;
import org.com.Model.Reprosetory.AdminRepro;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class AdminServices {

	@Autowired
	AdminRepro pr;

	public ArrayList<Admin> getAllAdmin() {
		ArrayList<Admin> p = new ArrayList<Admin>();
		Iterator I = pr.findAll().iterator();

		while (I.hasNext()) {
			Admin w = (Admin) I.next();
			p.add(w);
		}
		System.out.println(p);
		return p;
	}
	
	public void addadmin(Admin a) 
	{
		pr.save(a); 
				
	}
	/*public Admin findbyid(String d) 
	{
		
		Admin AD = (Admin)pr.findAll(d).get();
		
		return AD;
	}*/
	
}

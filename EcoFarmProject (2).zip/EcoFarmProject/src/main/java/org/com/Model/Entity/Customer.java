package org.com.Model.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Cu_Id;
	
	@Column(name =" Cu_Name")
	private String Cu_Name;
	
	@Column(name =" Cu_Location")
	private String Cu_Location;
	
	@Column(name =" Cu_Mobile")
	private String Cu_Mobile;
	
	@Column(name =" Cu_Username")
	private String Cu_Username;
	
	@Column(name =" Cu_Email")
	private String Cu_Email;
	
	@Column(name =" Cu_Password")
	private String Cu_Password;
	
	@Column(name =" Cu_Security")
	private String Cu_Security;
	
	@Column(name =" Cu_Answer")
	private String Cu_Answer;
	public int getCu_Id() {
		return Cu_Id;
	}
	public void setCu_Id(int cu_Id) {
		Cu_Id = cu_Id;
	}
	public String getCu_Name() {
		return Cu_Name;
	}
	public void setCu_Name(String cu_Name) {
		Cu_Name = cu_Name;
	}
	public String getCu_Location() {
		return Cu_Location;
	}
	public void setCu_Location(String cu_Location) {
		Cu_Location = cu_Location;
	}
	public String getCu_Mobile() {
		return Cu_Mobile;
	}
	public void setCu_Mobile(String cu_Mobile) {
		Cu_Mobile = cu_Mobile;
	}
	public String getCu_Username() {
		return Cu_Username;
	}
	public void setCu_Username(String cu_Username) {
		Cu_Username = cu_Username;
	}
	public String getCu_Email() {
		return Cu_Email;
	}
	public void setCu_Email(String cu_Email) {
		Cu_Email = cu_Email;
	}
	public String getCu_Password() {
		return Cu_Password;
	}
	public void setCu_Password(String cu_Password) {
		Cu_Password = cu_Password;
	}
	public String getCu_Security() {
		return Cu_Security;
	}
	public void setCu_Security(String cu_Security) {
		Cu_Security = cu_Security;
	}
	public String getCu_Answer() {
		return Cu_Answer;
	}
	public void setCu_Answer(String cu_Answer) {
		Cu_Answer = cu_Answer;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

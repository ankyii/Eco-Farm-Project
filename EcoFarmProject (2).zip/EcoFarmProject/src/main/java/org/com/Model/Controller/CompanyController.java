package org.com.Model.Controller;

import java.util.List;

import org.com.Model.Entity.Company;
import org.com.Model.Entity.Customer;
import org.com.Model.Services.CompanyService;
import org.com.Model.Services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class CompanyController {
	
	@Autowired
	CompanyService Ab;
	
	@GetMapping(path="/company")
	public List<Company> getAllProduct()
	{
		return Ab.getAllCompany();
	}
	
	@GetMapping("/company/{cid}")
	public Company getCompanyId(@PathVariable("cid") int d)
	{
		return Ab.findbyid(d);
	}
	
	@PostMapping("/addCompany")
	public int saveCompany(@RequestBody Company pd)
	{
		Ab.addCompany(pd);
		return pd.getC_Id();
		
	}
	
	@PutMapping("/updatecompany")
	public int updateCompany(@RequestBody Company pd)
	{	   
		Ab.updateCompany(pd);
		return pd.getC_Id();
		
	}
	
	@DeleteMapping("/deletecompany/{id}")
	public void deleteCustomer(@PathVariable("cid") int d)
	{
		Ab.deleteCompany(d);		
	}


}

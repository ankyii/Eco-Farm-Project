package org.com.Model.Controller;

import java.util.List;

import org.com.Model.Entity.Cart;
import org.com.Model.Entity.Product;
import org.com.Model.Services.CartServices;
import org.com.Model.Services.ProductServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class CartController {
	@Autowired
	CartServices Ab;
	
	@GetMapping(path="/carts")
	public List<Cart> getAllcart()
	{
		return Ab.getAllCart();
	}
	
	@GetMapping("/carts/{pid}")
	public Cart getCarttID(@PathVariable("pid") int d)
	{
		return Ab.findbyid(d);
	}
	
	@PostMapping("/addcart")
	public int saveCart(@RequestBody Cart pd)
	{
		Ab.addCart(pd);
		return pd.getP_Code();
		
	}
	
	@PutMapping("/updatecart")
	public int updateCart(@RequestBody Cart pd)
	{	   
		Ab.updateproduct(pd);
		return pd.getP_Code();
		
	}
	
	@DeleteMapping("/deletecart/{id}")
	public void deletecart(@PathVariable("pid") int d)
	{
		Ab.deletecart(d);	
}
}
}

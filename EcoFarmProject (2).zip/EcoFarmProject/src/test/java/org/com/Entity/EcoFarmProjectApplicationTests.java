package org.com.Entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoFarmProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
